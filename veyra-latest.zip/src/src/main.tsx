import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles.css";
import { applyTheme } from "./theme";

applyTheme("dark");

// 不用 StrictMode：开发模式双渲染会让 1.5s 轮询下的重渲染翻倍，切换 tab 明显卡顿
createRoot(document.getElementById("root")!).render(<App />);
