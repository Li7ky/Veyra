/// <reference types="vite/client" />

export interface ProfileRich {
  uid: string;
  name: string;
  type: "remote" | "local" | "merge" | "script" | "rules" | "proxies" | "groups";
  url?: string | null;
  enabled: boolean;
  global: boolean;
  updatedAt: number;
  file: string;
  size: number;
  binds?: {
    merge?: string | null;
    script?: string | null;
    rules?: string | null;
    proxies?: string | null;
    groups?: string | null;
  };
}

export interface HomeCards {
  subscription: boolean;
  node: boolean;
  network: boolean;
  mode: boolean;
  traffic: boolean;
  webtest: boolean;
  ip: boolean;
  core: boolean;
  system: boolean;
}

export interface AppSettings {
  mixedPort: number;
  controllerPort: number;
  secret: string;
  allowLan: boolean;
  logLevel: string;
  autoTest: boolean;
  autoPick: boolean;
  autoTestIntervalSec: number;
  subAutoUpdateMin: number;
  closeToTray: boolean;
  startWithWindows: boolean;
  startMinimized: boolean;
  proxyBypass: string;
  theme: string;
  core: string;
  proxyMode?: string;
  proxyGuard?: boolean;
  disconnectOnProxyOff?: boolean;
  bindAddress?: string;
  tunEnable?: boolean;
  tunStack?: string;
  tunAutoRoute?: boolean;
  tunStrictRoute?: boolean;
  tunAutoDetect?: boolean;
  tunSniff?: boolean;
  tunMtu?: number;
  tunDevice?: string;
  tunDnsHijack?: string[];
  serviceMode?: boolean;
  dnsOverride?: boolean;
  dnsEnable?: boolean;
  dnsListen?: string;
  dnsIpv6?: boolean;
  dnsMode?: string;
  dnsFakeIpRange?: string;
  dnsFakeIpFilter?: string[];
  dnsNameserver?: string[];
  dnsFallback?: string[];
  dnsDefaultNs?: string[];
  dnsHosts?: Record<string, string>;
  hotkeyToggleProxy?: string;
  hotkeyToggleWindow?: string;
  hotkeyModeRule?: string;
  hotkeyModeGlobal?: string;
  hotkeyModeDirect?: string;
  lightweightMode?: boolean;
  locale?: string;
  themeColor?: string;
  customCss?: string;
  webdavUrl?: string;
  webdavUser?: string;
  webdavPass?: string;
  webdavRemote?: string;
  logMaxLines?: number;
  logAutoCleanDays?: number;
  mihomoChannel?: string;
  webuiPrefer?: string;
  unifiedDelay?: boolean;
  tcpConcurrent?: boolean;
  subRetry?: number;
  subTimeoutSec?: number;
  subUpdateViaProxy?: boolean;
  windowBounds?: { x?: number; y?: number; width?: number; height?: number } | null;
  portableMode?: boolean;
  nodeSort?: string;
  trayGroupIcons?: boolean;
  homeCards?: HomeCards;
}

export interface ProxyNode {
  type?: string;
  name?: string;
  now?: string;
  all?: string[];
  history?: { delay?: number }[];
  udp?: boolean;
  xudp?: boolean;
}

export interface ClashConfig {
  mode?: string;
  "mixed-port"?: number;
  port?: number;
  "socks-port"?: number;
}

export interface ConnectionItem {
  id: string;
  upload?: number;
  download?: number;
  start?: string;
  chains?: string[];
  rule?: string;
  rulePayload?: string;
  metadata?: {
    host?: string;
    destinationIP?: string;
    destinationPort?: string | number;
    process?: string;
    network?: string;
    type?: string;
  };
}

export interface VeyraAPI {
  minimize: () => Promise<void>;
  maximize: () => Promise<void>;
  close: () => Promise<void>;
  startCore: () => Promise<unknown>;
  stopCore: () => Promise<unknown>;
  restartCore: () => Promise<unknown>;
  coreStatus: () => Promise<{ running: boolean; version?: unknown; pid?: number | null }>;
  coreInfo: () => Promise<{
    path: string;
    exists: boolean;
    size: number;
    mtime: number | null;
    fileVersion: string | null;
    build: string;
    buildAsset: string;
    cpu: string;
    cpuCount: number;
    arch: string;
    pid: number | null;
    running: boolean;
    mixedPort: number;
    controller: string;
    secret: string;
    core: string;
    apiVersion?: { version?: string } | null;
  }>;
  checkCoreUpdate: () => Promise<{ latest: string; name?: string; url?: string }>;
  updateCore: () => Promise<unknown>;
  matchCoreBuild: () => Promise<unknown>;
  switchCore: (core: string) => Promise<unknown>;
  coreList: () => Promise<{
    active: string;
    mihomo: { installed: boolean; version: string };
    singbox: { installed: boolean; version: string };
  }>;
  onCoreStatus: (cb: (data: unknown) => void) => () => void;
  onCoreLog: (cb: (line: string) => void) => () => void;
  onCoreError: (cb: (msg: string) => void) => () => void;
  onSystemProxyChanged: (cb: (data: { enabled?: boolean }) => void) => () => void;
  overview: () => Promise<{
    proxies: { proxies?: Record<string, ProxyNode> };
    configs: ClashConfig;
    connections: {
      downloadTotal?: number;
      uploadTotal?: number;
      connections?: ConnectionItem[];
    };
    connectionsCount?: number;
    mixedPort: number;
    controller: string;
    preferredPort?: number;
    coreMemoryMB?: number;
  }>;
  ports: () => Promise<{ mixedPort: number; controller: string; preferredPort: number }>;
  selectProxy: (group: string, name: string) => Promise<unknown>;
  testDelay: (name: string) => Promise<{ status: number; data: { delay?: number } }>;
  setMode: (mode: string) => Promise<unknown>;
  setSystemProxy: (enable: boolean) => Promise<{
    ok: boolean;
    enabled?: boolean;
    server?: string;
    bypass?: string;
  }>;
  systemProxyStatus: () => Promise<{ enabled: boolean; server?: string; rawEnabled?: boolean }>;
  patchConfig: (body: Record<string, unknown>) => Promise<unknown>;
  closeAllConnections: () => Promise<unknown>;
  listConnections?: () => Promise<{
    connections?: ConnectionItem[];
    downloadTotal?: number;
    uploadTotal?: number;
  }>;
  closeConnection?: (id: string) => Promise<unknown>;
  listRules?: () => Promise<{ rules?: { payload: string; type?: string }[] }>;
  saveVisualRules?: (rules: string[]) => Promise<{ ok: boolean; warnings?: string[] }>;
  listProviders?: () => Promise<{ proxies: Record<string, unknown>; rules: Record<string, unknown> }>;
  updateProvider?: (kind: "proxies" | "rules", name: string) => Promise<unknown>;
  listProfiles: () => Promise<
    {
      name: string;
      path: string;
      size: number;
      uid?: string;
      type?: string;
      enabled?: boolean;
      global?: boolean;
      url?: string;
      updatedAt?: number;
    }[]
  >;
  listProfilesRich?: () => Promise<ProfileRich[]>;
  importProfile: (payload: {
    name: string;
    content: string;
  }) => Promise<{ ok: boolean; path: string; mixedPort?: number; controller?: string; warnings?: string[] }>;
  importProfileUrl: (payload: {
    url: string;
    name?: string;
  }) => Promise<{
    ok: boolean;
    path: string;
    mixedPort?: number;
    controller?: string;
    bytes?: number;
    warnings?: string[];
  }>;
  listSubscriptions: () => Promise<{ url: string; name: string; updatedAt: number; userinfo?: { upload: number; download: number; total: number; expire: number } }[]>;
  readActiveProfile: () => Promise<string>;
  activateProfile?: (uid: string) => Promise<{ ok: boolean; warnings?: string[] }>;
  setProfileEnabled?: (uid: string, enabled: boolean) => Promise<unknown>;
  createEnhanceProfile?: (
    kind: "merge" | "script" | "rules" | "proxies" | "groups",
    name: string,
    global?: boolean
  ) => Promise<ProfileRich>;
  deleteProfile?: (uid: string) => Promise<unknown>;
  readProfile?: (uid: string) => Promise<string>;
  writeProfile?: (uid: string, content: string) => Promise<unknown>;
  setProfileBinds?: (uid: string, binds: ProfileRich["binds"]) => Promise<ProfileRich>;
  enhancePreview?: () => Promise<{ yaml: string; warnings: string[]; scriptLogs: string[] }>;
  enhanceApply?: () => Promise<{ ok: boolean; warnings: string[]; scriptLogs: string[] }>;
  readRuntime?: () => Promise<string>;
  writeRuntime?: (content: string) => Promise<{ ok: boolean }>;
  setProxyMode?: (mode: string) => Promise<unknown>;
  validateDns?: (ns: string) => Promise<{ ok: boolean; host?: string; error?: string }>;
  serviceStatus?: () => Promise<{ installed: boolean }>;
  serviceInstall?: () => Promise<unknown>;
  serviceUninstall?: () => Promise<unknown>;
  enableUwpLoopback?: () => Promise<unknown>;
  backupExport?: () => Promise<{ ok: boolean; path: string; bytes?: number }>;
  backupImport?: () => Promise<{ ok: boolean; canceled?: boolean }>;
  backupReveal?: () => Promise<unknown>;
  webdavUpload?: () => Promise<unknown>;
  webdavDownload?: () => Promise<unknown>;
  exitIp?: () => Promise<{ ip: string | null; country?: string; city?: string; isp?: string }>;
  detectProxyConflict?: () => Promise<string[]>;
  streamingUnlock?: () => Promise<
    { id: string; title?: string; ok: boolean; fail?: boolean; region?: string | null; status: number; note: string; testedAt?: number }[]
  >;
  streamingUnlockOne?: (id: string) => Promise<{
    id: string;
    title?: string;
    ok: boolean;
    fail?: boolean;
    region?: string | null;
    status: number;
    note: string;
    testedAt?: number;
  }>;
  unlockCatalog?: () => Promise<{ id: string; title: string }[]>;
  proxyEnvText?: () => Promise<{ text: string }>;
  importNodeUri?: (uri: string) => Promise<unknown>;
  openWebUI?: (which: string) => Promise<unknown>;
  clearLogFiles?: () => Promise<{ ok: boolean; removed: number }>;
  setNextUpdate?: (url: string, nextUpdateAt: number) => Promise<{ ok: boolean }>;
  vcRuntime?: () => Promise<{ ok: boolean; installed: boolean; downloadUrl?: string }>;
  downloadVc?: () => Promise<unknown>;
  onTrafficWs?: (cb: (data: unknown) => void) => () => void;
  onLightweight?: (cb: (data: { on?: boolean }) => void) => () => void;
  traffic: () => Promise<{
    downloadTotal?: number;
    uploadTotal?: number;
    connections?: ConnectionItem[];
  } | null>;
  openExternal: (url: string) => Promise<void>;
  getSettings: () => Promise<AppSettings>;
  setSettings: (patch: Partial<AppSettings>) => Promise<AppSettings>;
  applyNetwork: (patch: Partial<AppSettings>) => Promise<{
    settings: AppSettings;
    mixedPort: number;
    controller: string;
  }>;
  openPath: (which: string) => Promise<unknown>;
  copyText: (text: string) => Promise<unknown>;
  appInfo: () => Promise<{
    name: string;
    version: string;
    electron: string;
    platform: string;
    arch: string;
    isDev: boolean;
  }>;
}

declare global {
  interface Window {
    veyra?: VeyraAPI;
  }
}

export {};
